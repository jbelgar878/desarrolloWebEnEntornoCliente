const tasksAll =
    {
        "tasksList": [
            {
                "assignedTo": "Jon",
                "task": "Task_1",
                "duration": 20,
                "break": 5
            },
            {
                "assignedTo": "Doe",
                "task": "Task_2",
                "duration": 15,
                "break": 3
            },
            {
                "assignedTo": "Foo",
                "task": "Task_3",
                "duration": 60,
                "break": 15
            },
            {
                "assignedTo": "Jan",
                "task": "Task_4",
                "duration": 60,
                "break": 15
            },
            {
                "assignedTo": "Bar",
                "task": "Task_5",
                "duration": 60,
                "break": 15
            },
            {
                "assignedTo": "Fell",
                "task": "Task_6",
                "duration": 60,
                "break": 15
            }

        ]
    };